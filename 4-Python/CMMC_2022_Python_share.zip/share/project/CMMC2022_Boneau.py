# CMMC 2022 - Boneau project Python Solution
#
# Record of Revisions
#
# Date            Programmer              Descriptions of Change
# ====         ================           ======================
# 10-July-22        Michael Nunez               Original code
# 11-July-22        Michael Nunez        Exponential mean zero, in-class hot fixes

import numpy as np
from scipy import stats
import pingouin as pg
import matplotlib.pyplot as plt
import seaborn as sns


# ### Definitions
def IBM650EC_sim(distribution, n, var):
    """
	Simulates the normal, exponential, and rectangular (uniform) distributions from a simulated IBM 650 Electronic
	Computer used by Alan Boneau (1960)
	"""
    if distribution == "Normal":
        # np.random.normal is more intuitive than stats.norm.rvs()
        samples = np.random.normal(0, np.sqrt(var), size=n)
    elif distribution == "Exponential":
        # https://en.wikipedia.org/wiki/Exponential_distribution#Generating_exponential_variates
        # lambda = sqrt(1/var)
        unif_samps = np.random.uniform(0, 1, size=n)
        nonzero_samples = -np.log(unif_samps) / np.sqrt(1 / var)
        # The mean is 1/lambda, therefore make sure to also subtract the mean:
        samples = nonzero_samples - np.sqrt(var)
    elif (distribution == "Rectangular") or (distribution == "Uniform"):
        # https://en.wikipedia.org/wiki/Continuous_uniform_distribution
        # mu = (a+b)/2   implies    a = -b
        # var = (b-a)**2 / 12    implies  b = sqrt(12*var) + a
        # both imply   a = -sqrt(12*var)/2
        # implies      b = sqrt(12*var)/2
        lower_bound = -np.sqrt(12 * var) / 2
        upper_bound = np.sqrt(12 * var) / 2
        samples = np.random.uniform(lower_bound, upper_bound, size=n)
    else:
        raise ValueError('Distribution not recognized!')

    return samples


def hand_drawn_plots(dists, t_vals, ns, vars):
    """
	Draws similar plots to those in  Boneau, 1960: Psychological Bulletin
	"""
    # https://stackoverflow.com/questions/46889189/plot-a-density-function-above-a-histogram
    plt.xlim([-4, 4])
    sns.histplot(t_vals, kde=False)
    plt.title('Dist of t''s from %s(0, %d)%d-%s(0, %d)%d' %
              (dists[0], vars[0], ns[0], dists[1], vars[1], ns[1]))


# Specify experimental design
these_ns = np.array([[5, 5], [15, 15], [5, 15]])
these_vars = np.array([[1, 1], [4, 4], [1, 4], [4, 1]])
# these_ns = np.array([[5, 15]])
# these_vars = np.array([[1, 4], [4, 1]])
distributions = np.array(['Normal', 'Exponential', 'Rectangular'])

num_ts = 1000

# Send in the punch cards
for ns_row in range(these_ns.shape[0]):
    if ns_row == 3:
        n_var_rows = 4  # Don't use a constant
    else:
        n_var_rows = 3
    for var_row in range(n_var_rows):
        for this_dist1 in distributions:
            # Simulate both distributions
            this_n1 = these_ns[ns_row, 0]
            this_var1 = these_vars[var_row, 0]
            this_n2 = these_ns[ns_row, 1]
            this_var2 = these_vars[var_row, 1]
            for this_dist2 in distributions:
                t_vals = np.zeros((num_ts))
                p_vals = np.ones((num_ts)) * 100
                for i in range(num_ts):
                    samples_1 = IBM650EC_sim(this_dist1, this_n1, this_var1)
                    samples_2 = IBM650EC_sim(this_dist2, this_n2, this_var2)
                    ttest_results = pg.ttest(samples_1, samples_2, correction=False)  # Turn off Welch's correction
                    t_vals[i] = ttest_results['T']
                    p_vals[i] = ttest_results['p-val']
                all_dists = [this_dist1, this_dist2]
                all_ns = [this_n1, this_n2]
                all_vars = [this_var1, this_var2]
                # plt.figure()
                # hand_drawn_plots(all_dists, t_vals, all_ns, all_vars)
                # Show the plot in a loop
                # plt.show()
                percent_below = (np.sum((p_vals) < 0.05) / num_ts) * 100
                print('%.1f %% p-values < 0.05 from %s(0, %d)%d-%s(0, %d)%d.' % (
                    percent_below, all_dists[0], all_vars[0], all_ns[0], all_dists[1], all_vars[1], all_ns[1]))


# Show all the plots
plt.show()
