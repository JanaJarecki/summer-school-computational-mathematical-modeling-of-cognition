# Session 3 Python lecture - CMMC2022
#
# Record of Revisions
#
# Date            Programmer              Descriptions of Change
# ====         ================           ======================
# 26-Jan-22        Michael Nunez               Original code
# 08-July-22       Michael Nunez           Adaption for CMMC2022
# 11-July-22       Michael Nunez          Additions

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import pylint

# Some things I forgot to mention:
# %reset

my_tuple = (1, 2, 3, 9.13)  # Python tuple!
# del my_tuple


# See matplotlib cheatsheets: https://matplotlib.org/cheatsheets/

# IPython magic function:
# %pylab

# os.chdir('C:/Users/mnunez/')


# matplotlib histograms
my_norm_data = np.random.normal(loc=100, scale=10, size=1000)
plt.figure()  # Always run this first, like x11() in R
plt.hist(my_norm_data)

my_dependent = 10 + 3 * my_norm_data + np.random.normal(size=1000)
plt.figure()
plt.plot(my_norm_data, my_dependent)  # This is not a scatter plot but a line
plt.scatter(my_norm_data, my_dependent)  # This generates on top of the other figure

plt.figure()
plt.scatter(my_norm_data, my_dependent)
plt.xlabel('My normal data', fontsize=20)
plt.ylabel('My dependent data', fontsize=20)
plt.savefig("my_plots/my_scatter_plot.png", dpi=300)  # Saving plots is generally better


for i in range(10):
	plt.figure()
	plt.scatter(my_norm_data, my_dependent)
	plt.xlabel('My normal data', fontsize=20)
	plt.ylabel('My dependent data', fontsize=20)
	plt.show()  # You may need this in a loop

plt.show()  # You may need this in a loop
plt.close('all')  # Closes all my active windows


plt.figure()
x = np.linspace(0, 2 * np.pi, num=100)
np.size(x)
my_sine_wave = np.sin(x)
plt.plot(x, my_sine_wave)
plt.plot(x, np.cos(x), color='red', linewidth=3)

# Make some subplots
plt.figure()
fig, (ax1, ax2) = plt.subplots(1, 2)
ax1.plot(x, my_sine_wave)
ax2.plot(x, np.cos(x), color='red', linewidth=3)
#
# ax[1, 2].scatter(my_norm_data, my_dependent)
# ax[1, 2].set_xlabel('My independent variable')
# ax[1, 2].set_title('My scatter')
fig.suptitle('Multiple subplots', fontsize=10)  # fig.subtitle is the function I couldn't find during the video
plt.savefig("my_subplots.pdf", dpi=300)

# PEP 8 style recommendations

# pylint
sys.argv = ["pylint", "week3_2022_python_lecture.py"]
pylint.run_pylint()


# Variable names  ---------------------------

# Possible the most important thing you can do to make your code readable:
# Informative variable, function, and file names
# Even more important that comments

# Solution to Q2.3

# Don't do this (see Solution to Q2.3)
def f(x, y):
    x = "blue"
    y = "green"  # This could be "blue"
    w = np.array([(x, y)])
    return w


v = "grey"
z = "brown"
t = f(v, z)
print(t)

# Better
def color(color_me, grass_me):
    color_me = "blue"
    grass_me = "green"  # This could be "blue"
    colorful_items = np.array([(color_me, grass_me)])
    return colorful_items


sky = "grey"
ground = "brown"
these_items = color_it(sky, ground)
print(these_items)


# Bad comments and bad lines

# This line samples 1000 random normal variables and then adds that to 1000 uniform
# variables parameters. Then it takes the
# absolute value of that sum. Then it takes the square root of the sum. Then it 
# takes the mean of that sum. Then assigns it to the variable "mean_data"
abs_data = np.abs(np.random.normal(size=1000) + np.random.uniform(size=1000))
mean_data = np.mean(np.sqrt(abs_data))




