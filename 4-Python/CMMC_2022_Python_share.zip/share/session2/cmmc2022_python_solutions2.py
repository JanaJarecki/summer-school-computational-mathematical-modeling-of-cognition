# Python Script Example: 2022 Computational and Mathematical Modeling of Cognition
#
# Record of Revisions
#
# Date            Programmer              Descriptions of Change
# ====         ================           ======================
# 10-July-22        Michael Nunez               Original code

import numpy as np
from time import time, perf_counter

# Session 2: Flow control

# Q2.1

two_dice = np.random.choice(np.arange(1, 7), 2, replace=True)

if sum(two_dice) % 2 == 0:
    score = sum(two_dice) * min(two_dice)
else:
    score = -3 * sum(two_dice)

# Q2.2
# There are a few correct solutions

# solution given by a student
double_plus = np.array([])
for i in range(3, 18, 2):
    double_plus = np.append(double_plus, i)
print(double_plus)

# my solution
double_plus = np.array([])
for i in range(0, 8):
    double_plus = np.append(double_plus, 2 * i + 3)
print(double_plus)


# Q2.3
# This function does not run. Python CAN see global variables in a function. However because the line
# grass = "blue"
# is in the function. The global variable is not recognized.
# In R this would be possible because the global variable is found even when the variable grass is defined later
# Read more: https://www.w3schools.com/python/gloss_python_global_variables.asp

# Just remove the global variable. I edited a line to keep the intended behavior.
def color_it(color_me, grass_me):
    color_me = "blue"
    grass_me = "green"  # This could be "blue"
    colorful_items = np.array([(color_me, grass_me)])
    return colorful_items


sky = "grey"
ground = "brown"
these_items = color_it(sky, ground)
print(these_items)


# Q2.4
# answer derived from a student:
# With a class, one can create a new type of object. One can create attributes for this object,
# like variables and functions. One can create new variables that are assigned to this class.
# Read more: https://docs.python.org/3/tutorial/classes.html

# Complex number class
class ComplexNum:
    """Creates a complex number"""
    numtype = 'complex'

    def __init__(self, realpart, imagpart):
        self.r = realpart
        self.i = imagpart

    def vec_length(self):
        return np.sqrt(self.r ** 2 + self.i ** 2)

    def phase_angle(self):
        return np.arctan2(self.i, self.r)  # np.arctan() may not choose the correct quadrant


my_num = ComplexNum(3.0, 4.0)
print(my_num)
print((my_num.r, my_num.i))
print(my_num.numtype)
print(my_num.vec_length())
print(my_num.phase_angle())


# Q2.5 & Q2.7

# Some answers derived from a student
# Note you should place this function in its own Python script called "sequences.py"
def fibonacci(n):
    """
    This code returns the first n Fibonacci numbers.

    Parameters
    ----------

    n: a integer denote the size of the output numpy vector

    """
    result = np.array([])  # This is an empty array so the last line of this function works
    if n < 1:
        result = "n must be >= 1"
    if n == 1:
        result = np.array([0])
    if n >= 2:
        result = np.array([0, 1])
    for i in range(2, n):
        result = np.append(result, result[i - 1] + result[i - 2])
    return result


# We might keep a few definitions in their own .py file to group related functions
# We can then easily find, import, and share modules

# Q2.8

# write code to read a csv file
MyTitanicData = pd.read_csv('https://tinyurl.com/pipsTitanic')

for i in range(1, len(MyTitanicData)):
    should_it_print = (MyTitanicData["Sex"][i] == "female") & (
        MyTitanicData["Survived"][i] == 1) & (
        MyTitanicData["Sex"][i - 1] == "male")
    if should_it_print:
        print("I'll never let go, Jack. I'll never let go. I promise")


# Q2.9

# Starting from an arbitrary number is fine because we don't actually specify

def start_num(x):
    if x > 0:
        while x < 100:
            print(round(x, 2))
            x += 0.1

    elif x < 0:
        print("I'm not good at counting backwards")
        while x > -101:
            print(x)
            x -= 1

    else: # This statement is unncessary for full points
        print("Not sure what do with x = 0, try again!")


start_num(98)
start_num(-95)
start_num(0)
