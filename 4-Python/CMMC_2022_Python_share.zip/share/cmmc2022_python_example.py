# Python Script Example: 2022 Computational and Mathematical Modeling of Cognition
#
# Record of Revisions
#
# Date            Programmer              Descriptions of Change
# ====         ================           ======================
# 09-July-22        Michael Nunez               Original code

import os
import numpy as np
import pandas as pd

# Q1.0
# This is the answer the the example problem Q1.0 in a comment
this_variable = 1
print(this_variable)
# Out[3]: 1

# Q1.1